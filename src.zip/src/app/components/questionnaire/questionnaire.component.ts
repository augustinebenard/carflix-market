import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
declare const questionnaireStepper: any;
@Component({
  selector: 'app-questionnaire',
  templateUrl: './questionnaire.component.html',
  styleUrls: ['./questionnaire.component.css']
})
export class QuestionnaireComponent implements OnInit {
  carBrand: any = []
  estimatedBudget: any
  ageRange: any
  spendOnFuel: any
  dailyDrivingHrs: any
  maritalStatus: any
  married: boolean = false
  noOfChildren: any
  monthyMaintainanceCost: any
  carToBuy: any
  noOfSeats: any
  thingsYouLoveInCar: any
  form!: FormGroup
  questionnaireResponse!: {};
  constructor(private router: Router, private fb: FormBuilder) {


  }

  ngOnInit() {
    questionnaireStepper()
    this.form = this.fb.group({
      carBrand: ['', [Validators.required]],
      estimatedBudget: ['', [Validators.required]],
      ageRange: ['', [Validators.required]],
      spendOnFuel: ['', [Validators.required]],
      dailyDrivingHrs: ['', [Validators.required]],
      maritalStatus: ['', [Validators.required]],
      noOfChildren: ['', [Validators.required]],
      monthyMaintainanceCost: ['', [Validators.required]],
      carToBuy: ['', [Validators.required]],
      noOfSeats: ['', [Validators.required]],
      thingsYouLoveInCar: ['', [Validators.required]],

    })
  }

  submitQuestionnaires(){
    // this.questionnaireResponse={
    //   carBrand:this.carBrand,
    //   estimatedBudget:this.estimatedBudget,
    //   ageRange:this.ageRange,
    //   spendOnFuel:this.spendOnFuel,
    //   dailyDrivingHrs:this.dailyDrivingHrs,
    //   maritalStatus:this.maritalStatus,
    //   noOfChildren:this.noOfChildren,
    //   monthyMaintainanceCost:this.monthyMaintainanceCost,
    //   carToBuy:this.carToBuy,
    //   noOfSeats:this.noOfSeats,
    //   thingsYouLoveInCar:this.thingsYouLoveInCar,
    // }
    console.log(this.form.value);

  }

  gotoTopMarket() {
    this.router.navigate(['top-car'])

  }


  scrollToTop() {
    window.scrollTo(500, 0);
  }


  estimatedBudgetToggle(e: any) {

  }

  ageToggle(e: any) {

  }
  spendOnFuelToggle(e: any) {

  }
  dailyDrivingHrsToggle(e: any) {

  }
  maritalStatusToggle(e: any) {
    if (this.form.value.maritalStatus === "Yes") {
      this.married = true
    } else {
      this.married = false
    }
  }

  noOfChildrenToggle(e: any) {

  }
  monthyMaintainanceCostToggle(e: any) {

  }
  carToBuyToggle(e: any) {

  }
  noOfSeatsToggle(e: any) {

  }

  submitResponse() {
    console.log(this.estimatedBudget)

  }
  goHome() {
    this.router.navigate([''])
  }


}
