export const environment = {
  production: true,
  baseUrl: 'https://carflix.swipe.fund:2030/static/v1/mobile/product/',

};
